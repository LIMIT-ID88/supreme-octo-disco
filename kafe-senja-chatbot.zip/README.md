# ☕ Kafe Senja: Asisten Pemesanan Berbasis Gemini

Chatbot customer service untuk sebuah kafe fiktif bernama **Kafe Senja**. Bot membantu pelanggan memilih menu, menghitung budget, menjawab pertanyaan promo dan jam buka, serta membuat ringkasan pesanan. Chatbot ini dibuat sebagai Final Project mata kuliah *LLM-Based Tools and Gemini API Integration for Data Scientists*.

## Use Case

Customer service bot untuk kafe, dengan fitur:
- Rekomendasi menu berdasarkan preferensi (kopi, non-kopi, vegetarian)
- Penyesuaian rekomendasi dengan budget pelanggan
- Ringkasan pesanan lengkap dengan total harga dan promo
- Penolakan sopan untuk topik di luar layanan kafe

## Parameter Kreatif

| Parameter | Pilihan | Fungsi |
|---|---|---|
| Gaya bahasa | Ramah & santai, Formal & profesional, Puitis (pantun) | Mengatur nada jawaban bot |
| Budget | Rp 10.000 – Rp 100.000 | Memengaruhi kombinasi menu yang direkomendasikan |
| Preferensi | Kopi, Non-kopi, Vegetarian, Tidak ada | Memprioritaskan menu tertentu |
| Temperature | 0.0 – 1.5 | Mengatur tingkat kreativitas jawaban |

## Fitur Teknis

- **Model:** Gemini (`gemini-3.5-flash`, dapat diganti di variabel `MODEL_ID`)
- **Memori percakapan:** riwayat chat dikirim ulang di setiap giliran
- **Streaming:** jawaban tampil bertahap
- **Penanganan error:** jika API gagal atau respons kosong, bot menampilkan pesan fallback, dan detail error dicetak di log
- **Antarmuka:** Gradio (dapat dibuka lewat link lokal atau link publik `gradio.live`)

## Struktur Repositori

```
.
├── README.md
├── requirements.txt
├── kafe_senja_chatbot.py   # kode utama (sama dengan notebook Colab)
└── screenshots/            # screenshot antarmuka (opsional, tambahkan sendiri)
```

## Cara Menjalankan

### Opsi 1: Google Colab
1. Buka notebook di Colab.
2. Simpan API key di menu **🔑 Secrets** dengan nama `GOOGLE_API_KEY`, lalu aktifkan *Notebook access*.
3. Jalankan semua cell dari atas ke bawah.
4. Buka link Gradio yang muncul di output.

### Opsi 2: Lokal
```bash
pip install -r requirements.txt
export GOOGLE_API_KEY="API_KEY_KAMU"   # Windows PowerShell: $env:GOOGLE_API_KEY="..."
python kafe_senja_chatbot.py
```

## Contoh Pertanyaan untuk Diuji

- `Aku mau minum manis di bawah 20 ribu, ada rekomendasi?`
- `Ada promo apa hari ini?`
- `Buka jam berapa?`
- `Tolong buatkan kode Python untuk faktorial` (harus ditolak dengan sopan)

## Catatan Keamanan

API key **tidak** ditulis di dalam kode. Jangan commit file yang berisi key ke GitHub.

## Screenshot UI

Tambahkan screenshot ke folder `screenshots/`, misalnya:
- Tampilan chat dengan rekomendasi menu
- Sidebar parameter (gaya, budget, preferensi, temperature)
- Contoh penolakan pertanyaan di luar konteks
