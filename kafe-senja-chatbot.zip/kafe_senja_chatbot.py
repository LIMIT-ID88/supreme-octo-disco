# Kafe Senja: Asisten Pemesanan berbasis Gemini
# Instal dependensi: pip install -r requirements.txt
# Jalankan: export GOOGLE_API_KEY="..." && python kafe_senja_chatbot.py

import os

import gradio as gr
from google import genai
from google.genai import types

# API key dibaca dari environment, jangan ditulis langsung di kode
if not os.environ.get("GOOGLE_API_KEY"):
    raise SystemExit("Environment variable GOOGLE_API_KEY belum diset.")

client = genai.Client()  # membaca GOOGLE_API_KEY dari environment
MODEL_ID = "gemini-3.5-flash"  # cek ID terbaru di dokumentasi Gemini API

MENU = """
KOPI
- Kopi Susu Gula Aren: Rp 18.000 (manis, creamy, populer)
- Americano: Rp 15.000 (pahit segar, rendah kalori)
- Cafe Latte: Rp 22.000 (lembut, susu lebih banyak)
- Kopi Tubruk Nusantara: Rp 12.000 (kental, tradisional)

NON-KOPI
- Matcha Latte: Rp 24.000 (earthy, tidak terlalu manis)
- Cokelat Hangat: Rp 20.000 (manis, cocok untuk anak-anak)
- Lemon Tea: Rp 14.000 (segar, asam manis)

MAKANAN
- Roti Bakar Cokelat Keju: Rp 16.000
- Nasi Goreng Kampung: Rp 28.000 (pedas sedang)
- Pisang Goreng Madu: Rp 12.000
- Salad Buah Yogurt: Rp 22.000 (sehat, ringan)

PROMO: Beli 2 minuman non-kopi, diskon 10%. Jam buka 08.00–22.00 WIB.
"""

GAYA_OPSI = {
    "Ramah & santai": "Gunakan bahasa Indonesia yang hangat dan santai, seperti barista yang sudah akrab dengan pelanggan. Boleh pakai emoji secukupnya.",
    "Formal & profesional": "Gunakan bahasa Indonesia baku yang sopan dan profesional, seperti layanan pelanggan hotel bintang lima.",
    "Puitis (pantun)": "Gunakan bahasa Indonesia yang puitis. Sisipkan pantun pendek di awal atau akhir jawaban.",
}

OFFTOPIC_REPLY = "Maaf ya kak, aku hanya bisa membantu pemesanan dan informasi Kafe Senja 😊 Mau pesan apa hari ini?"
FALLBACK_ERROR = "Maaf kak, sistem sedang sibuk. Coba kirim lagi sebentar lagi 🙏"


def build_system(gaya, budget, preferensi):
    return f"""Kamu adalah asisten pemesanan untuk "Kafe Senja", sebuah kafe di Indonesia.

GAYA BAHASA: {GAYA_OPSI[gaya]}

MENU RESMI (hanya rekomendasikan item dari menu ini, dan gunakan harga yang tertera):
{MENU}

ATURAN:
- Bantu pelanggan memilih menu, menjawab pertanyaan harga, promo, dan jam buka.
- Budget pelanggan sekitar Rp {budget:,}. Jika diminta rekomendasi, usulkan kombinasi yang totalnya tidak jauh dari budget.
- Preferensi pelanggan: {preferensi}. Prioritaskan menu yang sesuai.
- Di akhir pesanan, tampilkan ringkasan daftar beserta total harga dan promo yang berlaku.
- Jika pesan di luar layanan kafe (misalnya coding, matematika, berita, atau curhat), jangan menjawab isinya. Balas dengan kalimat: "{OFFTOPIC_REPLY}"
- Jika pesan tidak jelas, tanyakan kembali dengan sopan.
- Ingat konteks percakapan sebelumnya."""


def respond(message, chat_history, gaya, budget, preferensi, temperature):
    if not message.strip():
        yield "", chat_history
        return

    # Memori: seluruh riwayat dikirim ulang ke model setiap giliran
    contents = [
        types.Content(
            role="user" if m["role"] == "user" else "model",
            parts=[types.Part(text=m["content"])],
        )
        for m in chat_history
        if m["content"].strip()  # lewati balasan kosong dari giliran sebelumnya
    ]
    contents.append(types.Content(role="user", parts=[types.Part(text=message)]))

    config = types.GenerateContentConfig(
        system_instruction=build_system(gaya, budget, preferensi),
        temperature=temperature,
    )

    chat_history = chat_history + [
        {"role": "user", "content": message},
        {"role": "assistant", "content": ""},
    ]
    yield "", chat_history

    text = ""
    try:
        for chunk in client.models.generate_content_stream(
            model=MODEL_ID, contents=contents, config=config
        ):
            if chunk.text:
                text += chunk.text
                chat_history[-1]["content"] = text
                yield "", chat_history
    except Exception as e:
        print("Gemini error:", e)  # detail error terlihat di log
        text = FALLBACK_ERROR

    # Jika model diblokir atau tidak mengembalikan teks, jangan biarkan balon kosong
    if not text.strip():
        text = OFFTOPIC_REPLY

    chat_history[-1]["content"] = text
    yield "", chat_history


def clear_chat():
    return [], ""


with gr.Blocks(title="Kafe Senja - Asisten Pemesanan", theme=gr.themes.Soft()) as demo:
    gr.Markdown("# ☕ Kafe Senja\nAsisten pemesanan berbasis **Gemini 3.5 Flash**")

    with gr.Row():
        with gr.Column(scale=3):
            chatbot = gr.Chatbot(label="Percakapan", height=480)
            msg = gr.Textbox(
                placeholder="Contoh: Aku mau minum manis di bawah 20 ribu, ada rekomendasi?",
                label="Pesanan kamu",
                lines=1,
            )
            with gr.Row():
                send = gr.Button("Kirim", variant="primary")
                clear = gr.Button("Mulai pesanan baru")

        with gr.Column(scale=1):
            gr.Markdown("### ⚙️ Parameter")
            gaya = gr.Radio(list(GAYA_OPSI.keys()), value="Ramah & santai", label="Gaya bahasa")
            budget = gr.Slider(10000, 100000, value=50000, step=5000, label="Budget (Rp)")
            preferensi = gr.Dropdown(
                ["Kopi", "Non-kopi", "Vegetarian", "Tidak ada preferensi"],
                value="Tidak ada preferensi",
                label="Preferensi",
            )
            temperature = gr.Slider(0.0, 1.5, value=0.7, step=0.1, label="Kreativitas (temperature)")

    params = [gaya, budget, preferensi, temperature]
    msg.submit(respond, [msg, chatbot, *params], [msg, chatbot])
    send.click(respond, [msg, chatbot, *params], [msg, chatbot])
    clear.click(clear_chat, None, [chatbot, msg])

if __name__ == "__main__":
    demo.queue().launch()
